CREATE DATABASE GP24;
USE GP24;

CREATE TABLE IF NOT EXISTS stock_data (
    stock_label VARCHAR(10),
    trading_date DATE,
    stock_price DECIMAL(10, 2)
);

LOAD DATA INFILE 'AMZN.csv'
INTO TABLE stock_data
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(@Date, @Price, @ignore1, @ignore2, @ignore3, @ignore4, @ignore5)
SET stock_label = 'AMZN', 
    trading_date = STR_TO_DATE(@Date, '%m/%d/%Y'),
    stock_price = @Price;
    
LOAD DATA INFILE 'AAPL.csv'
INTO TABLE stock_data
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(@Date, @Price, @ignore1, @ignore2, @ignore3, @ignore4, @ignore5)
SET stock_label = 'AAPL', 
    trading_date = STR_TO_DATE(@Date, '%m/%d/%Y'),
    stock_price = @Price;

LOAD DATA INFILE 'GOOGL.csv'
INTO TABLE stock_data
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(@Date, @Price, @ignore1, @ignore2, @ignore3, @ignore4, @ignore5)
SET stock_label = 'GOOGL', 
    trading_date = STR_TO_DATE(@Date, '%m/%d/%Y'),
    stock_price = @Price;

LOAD DATA INFILE 'META.csv'
INTO TABLE stock_data
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(@Date, @Price, @ignore1, @ignore2, @ignore3, @ignore4, @ignore5)
SET stock_label = 'META', 
    trading_date = STR_TO_DATE(@Date, '%m/%d/%Y'),
    stock_price = @Price;